buildContractCharts();
