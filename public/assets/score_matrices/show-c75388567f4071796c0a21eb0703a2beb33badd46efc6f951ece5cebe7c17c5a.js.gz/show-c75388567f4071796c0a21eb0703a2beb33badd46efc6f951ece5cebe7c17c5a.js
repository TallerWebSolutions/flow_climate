$('.select-answer').on('change', function() {
    this.form.submit();
});
