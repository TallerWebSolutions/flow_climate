function buildMoneyChart() {
    var lineDiv = $('#money-per-month-line');
    buildLineChart(lineDiv);
}
;
