$(function () {
    var columnDiv = $('#projects-count-column');
    buildColumnLineChart(columnDiv);
});
