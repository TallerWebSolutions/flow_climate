$(function () {
    var lineDiv = $('#flowpressure-per-month-line');
    buildLineChart(lineDiv);
});
