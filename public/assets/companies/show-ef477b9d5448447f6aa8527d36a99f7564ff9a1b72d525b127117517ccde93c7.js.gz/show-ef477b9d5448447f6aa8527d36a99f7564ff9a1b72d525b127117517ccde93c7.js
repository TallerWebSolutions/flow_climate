hideAllComponents();
activateTab();

$('#stamps').show();
$('#nav-item-stamps').addClass('active');

// buildFinancesHighcharts();
