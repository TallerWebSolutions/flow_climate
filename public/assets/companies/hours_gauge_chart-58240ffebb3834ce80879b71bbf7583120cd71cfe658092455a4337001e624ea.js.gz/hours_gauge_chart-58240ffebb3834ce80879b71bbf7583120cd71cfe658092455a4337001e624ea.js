$(function () {
    var gaugeDiv = $('#hours-gauge');
    buildGaugeChart(gaugeDiv);
});
