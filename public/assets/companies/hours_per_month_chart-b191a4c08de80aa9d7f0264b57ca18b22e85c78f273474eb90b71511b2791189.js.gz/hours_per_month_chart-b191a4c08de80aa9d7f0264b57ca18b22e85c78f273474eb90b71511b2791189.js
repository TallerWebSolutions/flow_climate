$(function () {
    var lineDiv = $('#hours-per-month-line');
    buildLineChart(lineDiv);
});
