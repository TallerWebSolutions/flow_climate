hideAllComponents($('.nav-item'));

activateTab();
$('#stamps').show();

$('#nav-item-stamps').addClass('active');

$("#general-loader").hide();

buildFinancesHighcharts();
