function buildActiveColumnChart() {
    var columnDiv = $('#projects-count-column');
    buildColumnLineChart(columnDiv);
}
;
