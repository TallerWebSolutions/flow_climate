$(function () {
    var columnDiv = $('#projects-count-column');
    buildColumnChart(columnDiv);
});
