$(function () {
    var lineDiv = $('#money-per-month-line');
    buildLineChart(lineDiv);
});
