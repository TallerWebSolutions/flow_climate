hideAllComponents($('.nav-item'));

$('#nav-item-stamps').addClass('active');
$('#stamps').show();

$('#company-teams-tab').addClass('active');

$("#general-loader").hide();

buildFinancesHighcharts();
