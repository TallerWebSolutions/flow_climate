$("#users-tab").addClass("active");
$("#users-table").show();
