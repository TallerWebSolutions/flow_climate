buildOperationsCharts();
buildManagerCharts();

$("#general-loader").hide();
