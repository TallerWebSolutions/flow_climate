$('#finances-list-tab').addClass('active');
$('#content-finances-list').show();
