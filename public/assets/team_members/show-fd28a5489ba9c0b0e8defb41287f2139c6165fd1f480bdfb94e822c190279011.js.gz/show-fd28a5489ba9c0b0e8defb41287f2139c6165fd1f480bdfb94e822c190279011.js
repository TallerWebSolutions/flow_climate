$('.col-table-details').hide();
