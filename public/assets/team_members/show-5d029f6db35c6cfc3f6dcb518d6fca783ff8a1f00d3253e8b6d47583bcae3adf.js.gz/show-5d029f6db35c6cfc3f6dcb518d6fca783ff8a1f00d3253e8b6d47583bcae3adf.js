$('.col-table-details').hide();
bindBlockFormModalAction();
