const pairingsDiv = $('#user-dashboard-pairing-line');
if (pairingsDiv.length !== 0) {
    buildLineChart(pairingsDiv);
};
