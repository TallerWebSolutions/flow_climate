$(document).ready(function() {
    buildStageHighcharts();
});
