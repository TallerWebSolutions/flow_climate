$(document).ready(function() {
    buildStageHighcharts();

    $("#stage-charts-tab").addClass("active");
    $("#stage-charts").show();

    $("#stage-project-associations-tab").addClass("active");
    $("#stage-projects-associations").show();
});
