$(".col-table-details").hide();
