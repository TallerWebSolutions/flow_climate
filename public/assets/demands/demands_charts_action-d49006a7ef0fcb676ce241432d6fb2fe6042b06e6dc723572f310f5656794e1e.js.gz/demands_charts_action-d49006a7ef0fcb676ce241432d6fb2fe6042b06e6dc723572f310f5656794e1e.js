$('#demands-charts-div').show();

buildDemandsTabCharts();
