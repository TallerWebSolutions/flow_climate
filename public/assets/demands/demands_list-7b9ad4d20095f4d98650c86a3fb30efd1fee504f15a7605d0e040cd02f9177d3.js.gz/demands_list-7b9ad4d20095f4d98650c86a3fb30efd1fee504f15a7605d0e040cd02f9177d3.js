$("#general-loader").hide();

buildDemandsTabCharts();

$('#demands-table-list').addClass("btn-active");

$('#demands-grouped-per-month-div').hide();
$('#demands-grouped-per-customer-div').hide();
$('#demands-grouped-per-stage-div').hide();
$('#content-charts').hide();
$('#flat-demands-div').show();
