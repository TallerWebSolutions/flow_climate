$("#general-loader").hide();

bindDemandFilterActions();
