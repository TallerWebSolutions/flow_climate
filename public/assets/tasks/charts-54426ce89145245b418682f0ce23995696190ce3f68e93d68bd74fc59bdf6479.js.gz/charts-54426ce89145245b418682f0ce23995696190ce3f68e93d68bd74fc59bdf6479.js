const tasksBasedScatterPlot = $("#tasks-completion-scatter");
if (tasksBasedScatterPlot.length !== 0) {
    buildScatterChart(tasksBasedScatterPlot);
};
