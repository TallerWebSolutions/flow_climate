const projectTaskBasedScatterPlot = $("#project-dashboard-task-completion-scatter");
if (projectTaskBasedScatterPlot.length !== 0) {
    buildScatterChart(projectTaskBasedScatterPlot);
};
