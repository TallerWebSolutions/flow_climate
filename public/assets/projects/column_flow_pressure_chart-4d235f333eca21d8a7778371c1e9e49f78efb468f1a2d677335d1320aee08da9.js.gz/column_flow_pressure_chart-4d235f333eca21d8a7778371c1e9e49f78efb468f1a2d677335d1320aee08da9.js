
$(function () {
    var columnDiv = $('#flowpressure-column');
    buildColumnChart(columnDiv);
});
