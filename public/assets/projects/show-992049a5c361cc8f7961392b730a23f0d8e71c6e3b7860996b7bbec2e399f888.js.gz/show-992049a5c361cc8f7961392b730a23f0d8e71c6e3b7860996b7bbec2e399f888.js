$(".loader").hide();
