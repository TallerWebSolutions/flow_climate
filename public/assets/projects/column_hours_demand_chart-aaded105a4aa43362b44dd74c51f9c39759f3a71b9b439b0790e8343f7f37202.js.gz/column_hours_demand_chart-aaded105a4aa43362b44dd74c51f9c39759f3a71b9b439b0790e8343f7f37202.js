$(function () {
    var columnDiv = $('#hours-column');
    buildColumnChart(columnDiv);
});
