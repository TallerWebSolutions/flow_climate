function buildDemandClassificationHighcharts() {
    var donutClassesOfServiceDiv = $('#class-of-services-donut');
    buildDonutChart(donutClassesOfServiceDiv);

    var donutDemandTypeDiv = $('#demand-type-donut');
    buildDonutChart(donutDemandTypeDiv);
}
;
