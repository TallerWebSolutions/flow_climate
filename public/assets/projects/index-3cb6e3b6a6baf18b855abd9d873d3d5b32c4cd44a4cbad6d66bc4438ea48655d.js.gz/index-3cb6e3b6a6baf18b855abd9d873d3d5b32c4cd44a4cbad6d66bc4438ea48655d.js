$(".col-table-details").hide();
bindSearchProjects();
