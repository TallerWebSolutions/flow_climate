$("#general-loader").hide();

$("#project-demands-dashboard").show();
