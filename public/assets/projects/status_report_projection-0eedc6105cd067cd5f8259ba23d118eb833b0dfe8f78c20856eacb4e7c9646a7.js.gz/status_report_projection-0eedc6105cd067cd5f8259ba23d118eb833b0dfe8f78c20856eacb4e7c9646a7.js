function buildStatusReportProjectionCharts() {
    const statusReportDatesOddsDiv = $('#status-report-dates-odds-column');
    buildColumnChart(statusReportDatesOddsDiv);
}
;
