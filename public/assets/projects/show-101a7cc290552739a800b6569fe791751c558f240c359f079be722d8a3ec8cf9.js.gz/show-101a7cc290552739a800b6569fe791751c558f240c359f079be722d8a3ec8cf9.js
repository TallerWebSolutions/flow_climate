$("#general-loader").hide();

$("#project-demands-dashboard").show();
$("#project-tasks-dashboard").hide();

$('#demands_charts_tab').addClass('active');
$('#tasks_charts_tab').removeClass('active');
