$(function () {
    var columnDiv = $('#throughput-column');
    buildColumnChart(columnDiv);
});
