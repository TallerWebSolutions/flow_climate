$(function () {
    var donutDiv = $('#risk-alert-color-backlog');
    buildDonutChart(donutDiv);
});

$(function () {
    var donutDiv = $('#risk-alert-color-flowpressure');
    buildDonutChart(donutDiv);
});

$(function () {
    var donutDiv = $('#risk-alert-color-profit');
    buildDonutChart(donutDiv);
});

$(function () {
    var donutDiv = $('#risk-alert-color-hours');
    buildDonutChart(donutDiv);
});

$(function () {
    var donutDiv = $('#risk-alert-color-money');
    buildDonutChart(donutDiv);
});
