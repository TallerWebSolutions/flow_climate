$(function () {
    var columnDiv = $('#cmd-line');
    buildLineChart(columnDiv);
});
