$("#general-loader").hide();

bindBlockFormModalAction();
