$("#general-loader").hide();

statusReportPeriodBehaviour();
operationalChartsPeriodBehaviour();
searchWeekBehaviour();
