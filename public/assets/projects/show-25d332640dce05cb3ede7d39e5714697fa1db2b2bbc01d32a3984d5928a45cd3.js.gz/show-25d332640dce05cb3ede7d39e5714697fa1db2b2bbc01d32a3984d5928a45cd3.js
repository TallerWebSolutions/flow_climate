$(".loader").hide();

statusReportPeriodBehaviour();
operationalChartsPeriodBehaviour();
searchWeekBehaviour();
