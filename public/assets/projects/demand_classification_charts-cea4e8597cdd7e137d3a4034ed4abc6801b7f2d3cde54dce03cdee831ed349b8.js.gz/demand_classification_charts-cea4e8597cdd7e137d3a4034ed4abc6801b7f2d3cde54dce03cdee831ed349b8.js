function buildDemandClassificationHighcharts() {
    let donutClassesOfServiceDiv = $('#class-of-services-donut');
    buildDonutChart(donutClassesOfServiceDiv);

    let donutDemandTypeDiv = $('#demand-type-donut');
    buildDonutChart(donutDemandTypeDiv);
};
