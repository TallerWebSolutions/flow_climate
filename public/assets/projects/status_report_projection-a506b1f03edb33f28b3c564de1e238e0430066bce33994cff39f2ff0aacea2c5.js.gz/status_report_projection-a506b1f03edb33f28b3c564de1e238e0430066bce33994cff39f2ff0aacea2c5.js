function buildStatusReportProjectionCharts() {
    var statusReportDatesOddsDiv = $('#status-report-dates-odds-column');
    buildColumnChart(statusReportDatesOddsDiv);
}
;
