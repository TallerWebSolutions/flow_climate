function buildClosingDashboardHighcharts() {
    const scopeDiscoveredDiv = $('#scope-discovered');
    buildBarChart(scopeDiscoveredDiv);
}
;
