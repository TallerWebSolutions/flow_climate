function buildStatusReportDashboardHighcharts() {
    const scopeDiscoveredDiv = $('#status-report-scope-discovered');
    buildBarChart(scopeDiscoveredDiv);
}
;
