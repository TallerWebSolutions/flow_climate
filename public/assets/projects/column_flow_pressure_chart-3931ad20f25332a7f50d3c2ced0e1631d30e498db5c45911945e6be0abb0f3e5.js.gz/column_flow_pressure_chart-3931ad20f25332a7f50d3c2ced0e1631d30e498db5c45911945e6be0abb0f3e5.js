
$(function () {
    console.log('montando');
    var columnDiv = $('#flowpressure-column');
    buildColumnChart(columnDiv);
});
