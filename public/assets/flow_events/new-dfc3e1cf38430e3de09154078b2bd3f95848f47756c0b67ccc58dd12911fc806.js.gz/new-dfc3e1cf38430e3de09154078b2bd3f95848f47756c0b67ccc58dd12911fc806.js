const searchTeamProjects = (companyId, teamId) => {
    searchProjectsByTeam(companyId, teamId)
};
